module Buildpack
  module Packager
    VERSION = '2.3.5'.freeze
  end
end
